# T-REX Pilot v2 Forensic Audit Report (Corrected)

## 1. Scope and Corrections
Independent, read-only functional pilot audit on Algorand Testnet.
- Audit v1 contained false negatives in method-detection for normal sessions due to incorrectly decoding binary ABI method selectors as UTF-8. 
- The method selector binary is now strictly checked using raw bytes / ABI selector hash.
- Independent receipt audit still confirms the normal transfers correctly.
- Invariant status is aggregated as `PARTIALLY_VERIFIABLE` rather than PASS, because `nonce_uniqueness` is strictly `NOT_VERIFIABLE` from receipts alone.

## 2. Protocol-Path Completion
- Normal receipt-conformant: 16 / 16
- Timeout receipt-conformant: 2 / 2
- Attested-fail receipt-conformant: 2 / 2
- **Overall protocol-conformant completion**: 20 / 20

## 3. Evidence Verification
- AppID verified: 20 / 20
- USDC receipt verified: 20 / 20
- Bounty receipt verified: 20 / 20
- Box state verified: 20 / 20

## 4. Network Fees
- See `results/pilot/pilot_v2_fee_audit.csv` for verified microALGO fees.
- *Testnet fees are logged in microALGO only. Mainnet cost equivalents are explicitly not computed or claimed.*

## 5. Latency
- See `results/pilot/pilot_v2_latency_audit.csv`. All percentiles derived are of metric type `VALID_CLIENT_SIDE`.

## 6. Invariants
- Mutual Exclusivity: PASS: 20, FAIL: 0, NA: 0
- Conservation: PASS: 20, FAIL: 0, NA: 0
- Single Payout: PASS: 20, FAIL: 0, NA: 0
- Nonce Uniqueness: PASS: 0, FAIL: 0, NA: 20
- **Aggregate Status**: PARTIALLY_VERIFIABLE (Not all invariants passed due to NA status on nonce uniqueness).

## 7. Limitations
- N=20 sessions, deterministic scenario assignment, Testnet only.
- Simulated/off-chain attesters, client-observed latency.
- No statistical power or security proof claimed.

No transactions were submitted during this audit. The audit is strictly read-only.
