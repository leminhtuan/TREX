# T-REX Pilot v2 Reproducibility Package

## 1. Scope
- Pilot chạy trên Algorand Testnet.
- AppID=769248116.
- ASA ID=10458941.

## 2. Audit Versions
- **Audit v1 (superseded)**: Chứa false negatives do binary ABI selector detection.
- **Audit v2 (final)**: Kết quả audit cuối cùng, phương pháp luận đã khắc phục false negatives.

## 3. Results Summary (Audit v2)
- Protocol-conformant completion = 20/20.
- Mutual exclusivity, conservation, single payout: PASS 20/20.
- Nonce uniqueness: NOT_VERIFIABLE 20/20.
- Aggregate invariant status: PARTIALLY_VERIFIABLE.

## 4. Metrics & Limitations
- Latency đo lường là VALID_CLIENT_SIDE.
- Testnet fees (đơn vị microALGO) không được phiên dịch thành Mainnet economic cost.
- Không có statistical power hay security guarantee claim nào được đưa ra.

## 5. Audit Policy
- Audit hoàn toàn Read-only.
- Zero transactions submitted.
